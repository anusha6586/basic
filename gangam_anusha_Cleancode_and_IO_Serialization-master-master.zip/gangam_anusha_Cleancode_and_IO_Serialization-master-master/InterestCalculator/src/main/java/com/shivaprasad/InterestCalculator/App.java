package com.shivaprasad.InterestCalculator;

/**
 * Hello world!
 *
 */
public class App 
{

}
